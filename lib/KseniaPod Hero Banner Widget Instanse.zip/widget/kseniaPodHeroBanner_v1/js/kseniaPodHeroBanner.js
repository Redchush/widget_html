define(
    ['knockout', 'jquery', 'moment'],



    function (ko, $, moment) {
        "use strict";

        const imageUrlPropertyBase = "imageUrl";
        const mobileImageUrlPropertyBase = "mobileImageUrl";
        const bannerLinkPropertyBase = "bannerLink";
        const startDatePropertyBase = "startDate";
        const endDatePropertyBase = "endDate";
        const bannerTextPropertyBase = "bannerText";

        function BannerItem(imageUrl, mobileImageUrl, bannerLink, startDate, endDate, bannerText) {
            var self = this;
            self.imageUrl = imageUrl;
            self.mobileImageUrl = mobileImageUrl;
            self.bannerLink = bannerLink;
            self.startDate = startDate;
            self.endDate = endDate;
            self.bannerText = bannerText;
        }

        function isImageEmpty(image) {
            for (var i in image) {
                if (image.hasOwnProperty(i) && image[i]) {
                    return false;
                }
            }
            return true;
        }

        function createBannerItem(widget, number) {
            return new BannerItem(widget[imageUrlPropertyBase + number].src(),
                widget[mobileImageUrlPropertyBase + number].src(),
                widget[bannerLinkPropertyBase + number](),
                widget[startDatePropertyBase + number](),
                widget[endDatePropertyBase + number](),
                widget[bannerTextPropertyBase + number]()
            );
        }

        return {
            onLoad: function(widget) {
                console.log(widget);
                widget.currentDate = moment().format('YYYYMMDD');
                widget.data = ko.observableArray();
                for (var i = 1; i <= 6; i++) {
                    var image = createBannerItem(widget, i);
                    if (!isImageEmpty(image)){
                        widget.data.push(image);
                    }
                }

                console.log(widget.data);

                widget.displayableItems = ko.computed(function() {
                    return ko.utils.arrayFilter(widget.data(), function (item) {
                        if (item.imageUrl){
                            if (item.startDate) {
                                if (item.endDate){
                                    if (widget.currentDate >= item.startDate && widget.currentDate <= item.endDate) {
                                        return item;
                                    }
                                } else if (widget.currentDate >= item.startDate) {
                                    return item;
                                }
                            } else {
                                if (item.endDate) {
                                    if (widget.currentDate <= item.endDate) {
                                        return item;
                                    }
                                } else {
                                    return item;
                                }
                            }

                        }
                    });
                });

                console.log(widget.displayableItems);
            },

            beforeAppear: function(page) {

                var selfWidget = this;
                function createCarousel(timeSwitchImage, boolLoopCarousel, boolAutoplayCarousel) {
                    boolAutoplayCarousel = boolAutoplayCarousel ? boolAutoplayCarousel : true;
                    timeSwitchImage = timeSwitchImage ? timeSwitchImage*1000 : 4000;
                    boolLoopCarousel = boolLoopCarousel ? boolLoopCarousel : false;

                    if(boolAutoplayCarousel === false) {
                        timeSwitchImage = false;
                    }
                    $('.carousel').carousel({interval: timeSwitchImage, wrap: boolLoopCarousel});
                }
                createCarousel(selfWidget.timeSwitchImage(), selfWidget.boolLoopCarousel(), selfWidget.boolAutoplayCarousel());
            }
        };


    }
);
